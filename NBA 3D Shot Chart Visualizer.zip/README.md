Link to blog post: https://www.phdata.io/blog/how-to-create-3d-basketball-shot-charts-with-streamlit-and-snowflake/
Link to GitHub code: https://github.com/LwrncLiu/march_madness/blob/main/main.py

Might need to install Git LFS (Large File Storage) - Used for the shot data as it is above 100 MB
  * https://git-lfs.com/
  * If too much work, just make changes to the csv and send to Don for github upload.

exp.py is a rough outline of how we can go about this for UI and backend.

Things to fix and Possible fixes:
  * Long load times
    * Seperating the CSV's based on names (ie. CSV1 for A-C, CSV2 for D-F, etc.)
  * Some shot makes not showing up, looks like made shots under the basket (x=25, y=0)
    * No solution
  * Showing two players on a court at the same time
    * No solution
