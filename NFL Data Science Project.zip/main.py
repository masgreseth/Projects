# from fitter import Fitter
import copy

from player import Player
from classic_lineup import Lineup
from operator import attrgetter
import pandas as pd
import random
from scipy.stats import lognorm
import math
import numpy as np
import matplotlib.pyplot as plt
import csv

def initialize_players(DK_filename):
    '''
    Initialize player objects based on the info from DraftKings CSV file
    :param DK_filename: string representing DK file name
    :return: list of player objects
    '''
    f = open(DK_filename, 'r')
    f.readline()
    info = f.readlines()
    player_list = []

    for i in range(len(info)):
        info[i] = info[i].split(',')
        true_position = info[i][0]
        name = info[i][2]
        id = info[i][3]
        salary = info[i][5]
        team = info[i][7]
        player = Player(name, true_position, team, salary, id)
        if true_position == 'DST':
            player.is_defense = True
        player_list.append(player)

    return player_list


def set_player_stats(player_list, ETR_filename):
    f = open(ETR_filename, 'r')
    f.readline()
    info = f.readlines()
    player_dict = {}
    for i in range(len(info)):
        info[i] = info[i].split(',')
        player_dict[info[i][0]] = info[i]

    for player in player_list:
        if player.name in list(player_dict.keys()):
            stats = player_dict[player.name]

            # PASSING
            if stats[5] != '':
                player.proj_attempts = float(stats[12])
                player.proj_completions = float(stats[13])
                player.comp_pct = player.proj_completions / player.proj_attempts
                player.interception_pct = float(stats[6]) / player.proj_attempts

            # RUSHING
            player.proj_rushes = float(stats[-1])
            if player.proj_rushes != 0:
                player.rush_td_pct = float(stats[-4]) / player.proj_rushes
                player.yards_per_carry = float(stats[-5]) / player.proj_rushes

            # RECEIVING
            if stats[7] != '':
                player.proj_receptions = float(stats[7])
                if player.proj_receptions != 0:
                    player.rec_td_pct = float(stats[9]) / player.proj_receptions
                    player.yards_per_catch = float(stats[8]) / player.proj_receptions

            player.opponent = stats[3]

    # for player in player_list:
    #     print(f'{player.name}: {player.proj_receptions} receptions, {player.yards_per_catch} ypc, {player.rec_td_pct} td pct')

    f.close()


def get_games(DK_filename):  # return unique games in a list
    '''
    Gets all of the games of the slate we are building lineups for (all unique games in DK CSV)
    :param DK_filename: string representing the DK file name
    :return: list of games in the format: ['MIN@TB', 'LAC@KC', ...]
    '''
    f = open(DK_filename, 'r')
    f.readline()
    info = f.readlines()
    games_list = []  # list of unique games in the form of ['TB@MIN', 'CAR@NO, ...]

    for i in range(len(info)):
        info[i] = info[i].split(',')
        game_info = info[i][6]
        game_info = game_info[:game_info.index(' ')]
        if game_info not in games_list:
            games_list.append(game_info)

    return games_list


def get_position_group(position, player_list):
    '''
    Gets a list of players of a specified position
    :param position: string representing the position that we want
    :param player_list: list of player objects
    :return: list of players of a specific position
    '''
    position_list = []
    for player in player_list:
        if player.position in position:
            position_list.append(player)
    return position_list


def set_player_score(value_list, fpts_list): # pass in sorted lists, set scores based on indicies
    for i, player in enumerate(fpts_list):
        value_index = value_list.index(player)
        fpts_index = i
        player.score = value_index + fpts_index
    # the lower the score, the better the pick

def valid_group(max_points, salary, rb, wr, te):
    # see if points are > than max points and no one is 0% owned and sal is good
    if rb.salary + wr.salary + te.salary <= salary:
        points = rb.fpts + wr.fpts + te.fpts
        if points > max_points:
            if rb.ownership > 0.0 and wr.ownership > 0.1 and te.ownership > 0.2:
                return points # to set new max_points
    return None



def find_optimal_group(skills, sal_remaining):
    # [rb1, rb2, wr1, wr2, wr3, te, flex]
    for player in skills:
        if player.position == 'RB':
            rb1 = player
            skills.remove(player)
            break
    for player in skills:
        if player.position == 'WR':
            wr1 = player
            skills.remove(player)
            break
    for player in skills:
        if player.position == 'WR':
            wr2 = player
            skills.remove(player)
            break
    # for player in skills:
    #     if player.position == 'TE':
    #         te = player
    #         skills.remove(player)
    #         break
    flex = skills[0]

    sal_remaining = sal_remaining - rb1.salary - wr1.salary - wr2.salary - flex.salary

    # now we need 1 rb, 1 wr, 1 te
    rb2 = None
    wr3 = None
    te1 = None

    rb_list = get_position_group('RB', skills)
    wr_list = get_position_group('WR', skills)
    te_list = get_position_group('TE', skills)

    max_points = 0
    for rb in rb_list[:25]:
        for wr in wr_list[:30]:
            for te in te_list[:10]:
                points = valid_group(max_points, sal_remaining, rb, wr, te)
                if points != None:
                    max_points = points
                    rb2 = rb
                    wr3 = wr
                    te1 = te
    if rb2 == None:
        return None


    # rb2 = None
    # wr3 = None
    # flex = None
    # max_points = 0
    # for a in range(20):
    #     for b in range(a, 20):
    #         for c in range(b, 20):
    #             if skills[a].fpts + skills[b].fpts + skills[c].fpts > max_points: # points validation
    #                 if skills[a].ownership > 0.01 and skills[b].ownership > 0.01 and skills[c].ownership > 0.01:
    #                     if skills[a].salary + skills[b].salary + skills[c].salary < sal_remaining and skills[a].name != skills[b].name and skills[b].name != skills[c].name: # salary and name validation
    #                         positions = [skills[a].position, skills[b].position, skills[c].position]
    #                         position_dict = {}
    #                         if 'RB' in positions and 'WR' in positions: #position validation
    #                             if 'TE' in positions:
    #                                 if skills[a].position == 'TE':
    #                                     position_dict['FLEX'] = skills[a]
    #                                     position_dict[skills[b].position] = skills[b]
    #                                     position_dict[skills[c].position] = skills[c]
    #                                 elif skills[b].position == 'TE':
    #                                     position_dict[skills[a].position] = skills[a]
    #                                     position_dict['FLEX'] = skills[b]
    #                                     position_dict[skills[c].position] = skills[c]
    #                                 else:
    #                                     position_dict[skills[a].position] = skills[a]
    #                                     position_dict[skills[b].position] = skills[b]
    #                                     position_dict['FLEX'] = skills[c]
    #                             else:
    #                                 position_dict[skills[a].position] = skills[a]
    #                                 if skills[b].position in list(position_dict.keys()):
    #                                     position_dict['FLEX'] = skills[b]
    #                                     position_dict[skills[c].position] = skills[c]
    #                                 else:
    #                                     position_dict[skills[b].position] = skills[b]
    #                                     position_dict['FLEX'] = skills[c]
    #                             rb2 = position_dict['RB']
    #                             wr3 = position_dict['WR']
    #                             flex = position_dict['FLEX']

    return {'RB1': rb1, 'RB2': rb2, 'WR1': wr1, 'WR2': wr2, 'WR3': wr3, 'TE': te1, 'FLEX': flex}

def choose_defense(dst_list, sal_remaining, qb):
    for d in dst_list:
        if d.salary <= sal_remaining and d.opponent != qb.team and d.team != qb.team:
            return d

def get_first_position(position, player_list):
    # get first occurence of a position given a list (prolly sorted
    for p in player_list:
        if p.position == position:
            return p

def remove_player(player_list, player):
    for p in player_list:
        if p.name == player.name:
            player_list.remove(p)
            return

def check_stack(lineup_list):
    wr_wr = 0
    wr_rb = 0
    wr_te = 0
    no_stack = 0
    for lin in lineup_list:
        team = lin.qb.team
        if lin.wr2.team == team or lin.wr3.team == team:
            wr_wr += 1
        elif lin.rb1.team == team or lin.rb2.team == team:
            wr_rb += 1
        elif lin.te.team == team:
            wr_te += 1
        else:
            no_stack += 1
    print(f'WR/WR: {wr_wr / len(lineup_list) * 100}%')
    print(f'WR/RB: {wr_rb / len(lineup_list) * 100}%')
    print(f'WR/TE: {wr_te / len(lineup_list) * 100}%')
    print(f'NO stack: {no_stack / len(lineup_list) * 100}%')

def create_stacked_lineup(player_list):
    player_list_clone = copy.deepcopy(player_list)
    sorted_value_list = sorted(player_list, key=attrgetter('value'))
    sorted_value_list.reverse()

    sorted_point_list = sorted(player_list, key=attrgetter('fpts'))
    sorted_point_list.reverse()

    set_player_score(sorted_value_list, sorted_point_list)
    sorted_score_list = sorted(player_list, key=attrgetter('score'))

    qbs = get_position_group('QB', sorted_score_list)
    QB = qbs[0]

    qb_team_list = get_team_players(player_list, QB.team)
    team_skills = get_position_group('RB/WR/TE', qb_team_list)
    team_skills = sorted(team_skills, key=attrgetter('score'))
    WR1 = get_first_position('WR', team_skills)
    team_skills.remove(WR1)

    # other part of double stack, decide WR/WR, WR/RB, or WR/TE
    team_rb = get_first_position('RB', team_skills)
    team_wr = get_first_position('WR', team_skills)
    team_te = get_first_position('TE', team_skills)

    other_stack = sorted([team_wr, team_te, team_rb], key=attrgetter('score'))[0]
    remove_player(player_list_clone, WR1)
    remove_player(player_list_clone, other_stack)

    need = ['RB', 'RB', 'WR', 'WR', 'TE', 'WR']
    if other_stack.position == 'TE':
        TE = other_stack
        need.remove('TE')
    elif other_stack.position == 'RB':
        RB1 = other_stack
        need.remove('RB')
    else:
        WR2 = other_stack
        need.remove('WR')

    if 'TE' in need:
        TE = sorted(get_position_group('TE', player_list), key=attrgetter('score'))[0]

    if need.count('WR') == 3:
        WR2 = sorted(get_position_group('WR', player_list_clone), key=attrgetter('score'))[0]
        remove_player(player_list_clone, WR2)

    if need.count('RB') == 2:
        RB1 = sorted(get_position_group('RB', player_list_clone), key=attrgetter('score'))[0]
        remove_player(player_list_clone, RB1)

    # now need RB2, WR3, FLEX (WR)
    WR3 = sorted(get_position_group('WR', player_list_clone), key=attrgetter('score'))[0]
    remove_player(player_list_clone, WR3)

    sal_remaining = 50000 - 3000 - QB.salary - RB1.salary - WR1.salary - WR2.salary - WR3.salary - TE.salary
    rbs = sorted(get_position_group('RB', player_list_clone), key=attrgetter('score'))
    wrs = sorted(get_position_group('WR', player_list_clone), key=attrgetter('score'))
    max_points = 0
    RB2 = None
    FLEX = None
    for rb in rbs:
        for wr in wrs:
            if rb.salary + wr.salary <= sal_remaining:
                if rb.fpts + wr.fpts > max_points:
                    max_points = rb.fpts + wr.fpts
                    RB2 = rb
                    FLEX = wr

    if RB2 == None:
        return None

    dsts = sorted(get_position_group('DST', player_list), key=attrgetter('salary'), reverse=True)
    DST = choose_defense(dsts, sal_remaining + 3000 - RB2.salary - FLEX.salary, QB)
    # if DST == None:
    #     return None
    lineup = Lineup(QB, RB1, RB2, WR1, WR2, WR3, TE, FLEX, DST)
    return lineup









def create_lineup(player_list): # knapsack optimization
    sorted_value_list = sorted(player_list, key=attrgetter('value'))
    sorted_value_list.reverse()

    sorted_point_list = sorted(player_list, key=attrgetter('fpts'))
    sorted_point_list.reverse()

    set_player_score(sorted_value_list, sorted_point_list)
    sorted_score_list = sorted(player_list, key=attrgetter('score'))

    # for p in sorted_score_list:
    #     print(f'{p.name}: {p.score}, {p.fpts}, ${p.salary}')

    qbs = get_position_group('QB', sorted_score_list)
    QB = qbs[0]

    skills = get_position_group('RB/WR/TE', sorted_score_list)
    dst = get_position_group('DST', sorted_score_list)
    dst_salaries =[]
    for d in dst:
        dst_salaries.append(d.salary)
    np_dst = np.array(dst_salaries)
    optimal_skills = find_optimal_group(skills, 50000 - QB.salary - np.mean(np_dst))
    if optimal_skills == None:
        return None

    RB1 = optimal_skills['RB1']
    RB2 = optimal_skills['RB2']
    WR1 = optimal_skills['WR1']
    WR2 = optimal_skills['WR2']
    WR3 = optimal_skills['WR3']
    TE = optimal_skills['TE']
    FLEX = optimal_skills['FLEX']

    sal_rem = 50000 - RB1.salary - RB2.salary - WR1.salary - WR2.salary - WR3.salary - TE.salary - FLEX.salary
    DST = choose_defense(dst, sal_rem,QB)

    lineup = Lineup(QB, RB1, RB2, WR1, WR2, WR3, TE, FLEX, DST)
    #print(lineup)
    return lineup

def get_team_players(player_list, team):
    '''
    Gets a list of players of a specific team
    :param player_list: list of player objects
    :param team: string representing the desired team
    :return: list of player objects
    '''
    team_players_list = []
    for player in player_list:
        if player.team == team:
            team_players_list.append(player)
    return team_players_list

def set_rush_share(team_list): # return total rushes
    total_rushes = 0
    for player in team_list:
        total_rushes += player.proj_rushes
    for player in player_list:
        player.rush_share = player.proj_rushes / total_rushes
    return round(total_rushes)


def decide_runner(team_list):
    players = []
    rush_shares = []
    for player in team_list:
        players.append(player)
        rush_shares.append(player.rush_share)
    target = random.choices(players, weights=rush_shares, k=1)
    return target[0]

def decide_target(team_list):
    players = []
    target_shares = []
    for player in team_list:
        players.append(player)
        target_shares.append(player.reception_share)
    target = random.choices(players, weights=target_shares, k=1)
    return target[0]

def check_fumble(player, defense):
    check_fumble = random.random()
    if check_fumble <= player.fumble_pct:
        defense.fumbles_recovered += 1
        player.fumbles += 1
        print('fumble')
        return True
    return False

def get_defense(team_list):
    for p in team_list:
        if p.is_defense:
            return p
    return None

def get_qb(team_list):
    offense_team_list = sorted(team_list, key=attrgetter('proj_attempts'))
    qb = offense_team_list[-1]
    return qb

def get_reception_length(player):
    return lognorm.rvs(s=.5, loc=-4, scale=13) * (1 + (player.yards_per_catch / 100))

def get_rush_length(player):
    return lognorm.rvs(s=.6, loc=-3, scale=8) * (1 + (player.yards_per_carry / 100))

def check_defensive_td(defense, type):
    check_td = random.random()
    if type == 'interception':
        if check_td < .1097: # pick six rate
            defense.defensive_tds += 1
    elif type == 'fumble':
        if check_td < .084: # scoop and score rate
            defense.defensive_tds += 1
    else:
        print('wrong input for type in check_defensive_td')

def set_reception_share(team_list):
    total_receptions = 0
    for player in team_list:
        total_receptions += player.proj_receptions
    for player in team_list:
        player.reception_share = player.proj_receptions / total_receptions
    return round(total_receptions)


def simulate_pass(offense_team_list, defense_team_list):
    qb = get_qb(offense_team_list)
    defense = get_defense(defense_team_list)

    check_sack = random.random()
    sack_pct = .065  # universal sack rate, change for individual qbs
    if check_sack <= sack_pct:
        defense.sacks += 1
        # print('sack')
        return

    if check_fumble(qb, defense):
        check_defensive_td(defense, 'fumble')

    check_interception = random.random()
    if check_interception <= qb.interception_pct:
        qb.interceptions_thrown += 1
        defense.interceptions += 1
        check_defensive_td(defense, 'interception')
        # print('interception')
        return

    check_catch = random.random()
    if check_catch <= qb.comp_pct:
        target = decide_target(offense_team_list)
        if check_fumble(target, defense):
            return
        yards = get_reception_length(target)
        target.receptions += 1
        target.rec_yds += yards
        qb.pass_yds += yards
        check_td = random.random()
        if check_td <= target.rec_td_pct:
            target.rec_tds += 1
            qb.pass_tds += 1
            defense.points_allowed += 7
            # print('TD')
        # print(target.name, 'catch for', round(yards), 'yards')
    else:
        # print('incomplete pass')
        return

def simulate_run(offense_team_list, defense_team_list):
    defense = get_defense(defense_team_list)
    runner = decide_runner(offense_team_list)
    if check_fumble(runner, defense):
        return
    yards = get_rush_length(runner)
    runner.rush_yds += yards
    check_td = random.random()
    if check_td <= runner.rec_td_pct:
        runner.rush_tds += 1
        defense.points_allowed += 7
    #     print('TD')
    # print(runner.name, 'rush for', str(round(yards)))


def simulate_game(player_list, home_team, away_team):
    home_team_players = get_team_players(player_list, home_team)
    away_team_players = get_team_players(player_list, away_team)

    home_rushes = set_rush_share(home_team_players)
    away_rushes = set_rush_share(away_team_players)

    home_passes = round(get_qb(home_team_players).proj_attempts)
    away_passes = round(get_qb(away_team_players).proj_attempts)

    set_reception_share(home_team_players)
    set_reception_share(away_team_players)

    for run in range(home_rushes):
        simulate_run(home_team_players, away_team_players)
    for run in range(away_rushes):
        simulate_run(away_team_players, home_team_players)

    for pass_attempt in range(home_passes):
        simulate_pass(home_team_players, away_team_players)
    for pass_attempt in range(away_passes):
        simulate_pass(away_team_players, home_team_players)

    for p in player_list:
        p.set_fpts()


def get_home_team(game):
    home = game[game.find('@')+1:]
    return home

def get_away_team(game):
    away = game[:game.find('@')]
    return away


def set_ownership(player_list, ownership_file):
    f = open(ownership_file, 'r')
    f.readline()
    info = f.readlines()
    player_dict = {}
    for i in range(len(info)):
        info[i] = info[i].split(',')
        player_dict[str(info[i][0])] = info[i]

    for player in player_list:
        if player.name in list(player_dict.keys()):
            stats = player_dict[player.name]
            total_ownership = float(stats[7]) / 100
            player.ownership = total_ownership

def choose_lineups(lineup_list, num_lineups):
    '''
    From a large list of lineups, returns num_linueps lineups in a list
    Lineups are chosen based on total fpts, cumulative ownership, and product ownership
    :param lineup_list: large list of lineups
    :param num_lineups: number of lineups to return
    :return: list of good lineups
    '''
    lineup_list = sorted(lineup_list, key=attrgetter('total_fpts'))
    lineup_list.reverse()
    for i in range(len(lineup_list)):
        lineup_list[i].score += i

    lineup_list = sorted(lineup_list, key=attrgetter('product_ownership'))
    for i in range(len(lineup_list)):
        lineup_list[i].score += (i)

    lineup_list = sorted(lineup_list, key=attrgetter('score'))
    return lineup_list[:num_lineups]

def print_ownership(lineup_list):
    player_dict = {}
    for lin in lineup_list:
        players = [lin.qb, lin.rb1, lin.rb2, lin.wr1, lin.wr2, lin.wr3, lin.te, lin.flex, lin.dst]
        for player in players:
            if player.name not in list(player_dict.keys()):
                player_dict[player.name] = 1
            else:
                player_dict[player.name] = player_dict[player.name] + 1

    player_list = sorted(player_dict.items(), key=lambda x: x[1])
    player_list.reverse()
    print(len(lineup_list))
    for player in player_list:
        print(f'{player[0]}: {round(player[1] / len(lineup_list) * 100, 1)}%')

def write_to_csv(lineup_list):
    ID_list = [['QB', 'RB', 'RB', 'WR', 'WR', 'WR', 'TE', 'FLEX', 'DST']]
    for lin in lineup_list:
        ID_list.append([lin.qb.id, lin.rb1.id, lin.rb2.id, lin.wr1.id, lin.wr2.id, lin.wr3.id, lin.te.id, lin.flex.id, lin.dst.id])

    with open('Entries.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(ID_list)

    print("\nWrite to csv successful")


def analyze_results(results_file, chosen_lineups):
    fpts_dict = {}
    results = open(results_file, 'r')
    results.readline()
    stats = results.readlines()
    i = 0
    stats[i] = stats[i].split(',')
    while stats[i][7] != '':
        name = stats[i][7]
        fpts = float(stats[i][10])
        fpts_dict[name] = fpts
        i += 1
        stats[i] = stats[i].split(',')

    actual = []
    proj = []
    for lin in chosen_lineups:
        proj.append(lin.total_fpts)
        if lin.wr2.name in list(fpts_dict.keys()):
            wr2_fpts = fpts_dict[lin.wr2.name]
        else:
            wr2_fpts = 0
        if lin.wr1.name in list(fpts_dict.keys()):
            wr1_fpts = fpts_dict[lin.wr1.name]
        else:
            wr1_fpts = 0
        if lin.wr3.name in list(fpts_dict.keys()):
            wr3_fpts = fpts_dict[lin.wr3.name]
        else:
            wr3_fpts = 0
        if lin.rb2.name in list(fpts_dict.keys()):
            rb2_fpts = fpts_dict[lin.rb2.name]
        else:
            rb2_fpts = 0
        if lin.flex.name in list(fpts_dict.keys()):
            flex_fpts = fpts_dict[lin.flex.name]
        else:
            flex_fpts = 0
        if lin.te.name in list(fpts_dict.keys()):
            te_fpts = fpts_dict[lin.te.name]
        else:
            te_fpts = 0
        actual_points = fpts_dict[lin.qb.name] + fpts_dict[lin.rb1.name] + rb2_fpts + \
        wr1_fpts + wr2_fpts + wr3_fpts + te_fpts + \
        flex_fpts + fpts_dict[lin.dst.name]
        actual.append(actual_points)

        if actual_points > 210:
            print("**ACTUAL POINTS**  " + str(actual_points))
            print(lin)

    x = np.array(proj)
    y = np.array(actual)

    avg = np.mean(y)

    plt.scatter(x, y)

    # calculate equation for trendline
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)

    # add trendline to plot
    plt.plot(x, p(x), color="red")
    print(str(z))
    print(str(p(100)))
    print(f'LINEUP FPT AVERAGE: {avg}')
    plt.show()


if __name__ == '__main__':
    DK_filename = "Week2.csv"
    stats_filename = "Week2 Projections.csv" # bad with weird names
    ownership_file = "Week2 Ownership.csv" # good with weird names
    results_file = "Week2_Classic_RESULTS.csv"

    num_lineups = 10
    num_sims = 10

    lineup_list = []
    lineup_list_stack = []
    for i in range(num_sims):
        if i % 100 == 0 and i != 0:
            print(str(i))
        player_list = initialize_players(DK_filename)
        games = get_games(DK_filename)
        set_player_stats(player_list, stats_filename)
        set_ownership(player_list, ownership_file)
        # for p in player_list:
        #     print(f'{p.name}: {p.ownership}')
        for game in games:
            simulate_game(player_list, get_home_team(game), get_away_team(game))


        # lin = create_lineup(player_list)
        stack_lin = create_stacked_lineup(player_list)
        if stack_lin != None:
            lineup_list_stack.append(stack_lin)
        # if lin != None:
        #     lineup_list.append(lin)


    chosen_lineups = choose_lineups(lineup_list, num_lineups)
    for lin in chosen_lineups:
        print(lin)
        print()
    # print('stack_ownership')
    # print_ownership(lineup_list_stack)
    # print()
    # print('normal ownership')
    # print_ownership(lineup_list)
    #
    # print('stack')
    # check_stack(lineup_list_stack)
    # print()
    # print('normal')
    # check_stack(lineup_list)

    # analyze_results(results_file, chosen_lineups)
    #
    write_to_csv(chosen_lineups)


    # bad_names = ['Travis Etienne Jr.', 'Kenneth Walker III', 'Jeff Wilson Jr.',
    #              'Gardner Minshew II', 'Nick Westbrook-Ikhine', 'J.J. Arcega-Whiteside', 'Jakeem Grant Sr.']






    # rushes = []
    # for i in range(2000):
    #     num = lognorm.rvs(s=.6, loc=-3, scale=8)
    #     rushes.append(num)
    # print(rushes)
    # r = np.array(rushes)
    # print('mean', str(np.mean(r)))
    # print('std', str(np.std(r)))
    # plt.hist(r, bins=25)
    # plt.show()


    # simulate_game(player_list, 'MIN', 'TB')
    # create_lineup(player_list)

    # ownership = [78,77,87,88,115,93,91,114,103,122,28,92,116,83,120,117,115]
    # own = np.array(ownership)
    # for i in range(20):
    #     print(random.gauss(np.mean(own), np.std(own)))
    # plt.plot(own)
    # plt.show()




    # df = pd.read_csv("NFL Play by Play 2009-2018 (v5).csv", usecols=['play_type', 'yards_gained', 'incomplete_pass'])
    # receptions = []
    # rushes = []
    # for index, row in df.iterrows():
    #     if row['play_type'] == 'pass' and row['incomplete_pass'] == 0.0:
    #         receptions.append(float(row['yards_gained']))
    # #     elif row['play_type'] == 'run':
    # #         rushes.append(float(row['yards_gained']))
    # # print('rec ' + str(len(receptions)))
    # # print('rush: ' + str(len(rushes)))
    # f = Fitter(random.sample(receptions, 200), distributions=['gamma',
    #                       'lognorm',
    #                       "beta",
    #                       "burr",
    #                       "norm"])
    # f.fit()
    # #print(f.summary())
    # best = f.get_best(method='sumsquare_error')
    # print(f.fitted_param["lognorm"])
    #
    # rushes_np = np.array(rushes)
    # receptions_np = np.array(receptions)
    # sample = random.sample(rushes, 1000)
    # sample_np = np.array(sample)
    # print(sample[:100])
    # mean = np.mean(sample)
    # stddev = np.std(sample)
    # print(str(mean))
    # print(str(stddev))
    #
    #
    # lognorm_values = lognorm.rvs(s=1, scale=math.exp(1), size=10)