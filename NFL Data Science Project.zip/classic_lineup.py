class Lineup:
    def __init__(self, qb, rb1, rb2, wr1, wr2, wr3, te, flex, dst):
        self.qb = qb
        self.rb1 = rb1
        self.rb2 = rb2
        self.wr1 = wr1
        self.wr2 = wr2
        self.wr3 = wr3
        self.te = te
        self.flex = flex
        self.dst = dst

        self.total_salary = qb.salary + rb1.salary + rb2.salary + wr1.salary + wr2.salary + \
                            wr3.salary + te.salary + flex.salary + dst.salary
        self.total_fpts = qb.fpts + rb1.fpts + rb2.fpts + wr1.fpts + wr2.fpts + \
                            wr3.fpts + te.fpts + flex.fpts + dst.fpts
        self.total_ownership = qb.ownership + rb1.ownership + rb2.ownership + wr1.ownership + wr2.ownership + \
                            wr3.ownership + te.ownership + flex.ownership + dst.ownership
        self.product_ownership = qb.ownership * rb1.ownership * rb2.ownership * wr1.ownership * wr2.ownership * \
                            wr3.ownership * te.ownership * flex.ownership * dst.ownership
        self.score = 0 # score based on fpts, cum ownership and prod ownership


    def __str__(self):
        return 'QB: ' + self.qb.name + '\nRB: ' + self.rb1.name + '\nRB: ' + self.rb2.name + '\nWR: ' + \
               self.wr1.name + '\nWR: ' + self.wr2.name + '\nWR: ' + self.wr3.name + '\nTE: ' + self.te.name + \
               '\nFLEX: ' + self.flex.name + '\nDST: ' + self.dst.name + '\nTOTAL SALARY: ' + str(self.total_salary) + \
               '\nCUM OWNERSHIP: ' + str(self.total_ownership) + '\nPROD OWNERSHIP: ' + str(self.product_ownership)
