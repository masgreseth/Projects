class Player:
    def __init__(self, name, position, team, salary, id):
        self.name = name
        self.position = position
        self.team = team
        self.salary = int(salary)
        self.id = id
        self.cpt_id = 0
        self.fpts = 0
        self.value = 0  # ftps / salary
        self.score = 0  # value and total fpts taken into account
        self.ownership = 0
        self.cpt_ownership = 0

        # PASSING
        self.proj_attempts = 0  # 12
        self.proj_completions = 0  # 13
        self.comp_pct = 0
        self.interception_pct = 0
        self.pass_yds = 0
        self.pass_tds = 0
        self.interceptions_thrown = 0

        # RUSHING
        self.proj_rushes = 0
        self.rush_share = 0
        self.fumble_pct = 0  # dont need
        self.rush_td_pct = 0
        self.yards_per_carry = 0
        self.rush_yds = 0
        self.rush_tds = 0
        self.fumbles = 0

        # RECEIVING
        self.proj_receptions = 0
        self.reception_share = 0  # need helper to set later
        self.catch_pct = 0  # dont need
        self.yards_per_catch = 0
        self.rec_td_pct = 0
        self.receptions = 0
        self.rec_yds = 0
        self.rec_tds = 0

        # DST
        self.is_defense = False
        self.interceptions = 0
        self.fumbles_recovered = 0
        self.sacks = 0
        self.defensive_tds = 0
        self.points_allowed = 0
        self.opponent = ''


    def __str__(self):
        return self.name + ', ' + self.team + ', ' + self.position + ', ' + self.position + ', ' + str(self.fpts) + ', ' + str(self.value)

    def print_stats(self):
        if self.position in ['WR', 'TE']:
            output = self.name + '\n' + str(self.receptions) + ' receptions for ' + str(round(self.rec_yds)) + ' yards, ' + str(self.rec_tds) + 'TDs\n'
        elif self.position == 'QB':
            output = self.name + '\n' + str(round(self.pass_yds)) + ' passing yards for ' + str(self.pass_tds) + ' TDs\n' + \
                     str(round(self.rush_yds)) + ' rush yards for ' + str(self.rush_tds) + ' TDs\n'
        elif self.position == 'RB':
            output = self.name + '\n' + str(round(self.rush_yds)) + ' yards for ' + str(self.rush_tds) + ' TDs\n' +\
                    str(self.receptions) + ' receptions for ' + str(round(self.rec_yds)) + ' yards, ' + str(self.rec_tds) + 'TDs\n'
        else:
            output = self.name + ' - ' + str(self.points_allowed) + ' points allowed\n' + str(self.interceptions) + ' ints, ' + str(self.fumbles_recovered) + \
                     ' fumble recoveries, ' + str(self.sacks) + ' sacks\n'
        print(output)

    def set_fpts(self):
        fpts = 4 * self.pass_tds + \
               .04 * self.pass_yds - \
               self.interceptions_thrown + \
               6 * self.rush_tds + \
               .1 * self.rush_yds + \
               .1 * self.rec_yds + \
               6 * self.rec_tds + \
               self.receptions
        # DEFENSE
        if self.position == 'DST':
            fpts += self.sacks + (2 * self.interceptions) + (2 * self.fumbles_recovered)
            if self.points_allowed == 0:
                fpts += 10
            elif 1 <= self.points_allowed <= 6:
                fpts += 7
            elif 7 <= self.points_allowed <= 13:
                fpts += 4
            elif 14 <= self.points_allowed <= 20:
                fpts += 1
            elif 21 <= self.points_allowed <= 27:
                fpts += 0
            elif 28 <= self.points_allowed <= 34:
                fpts -= 1
            else:
                fpts -= 4
        if self.rush_yds >= 100:
            fpts += 3
        if self.rec_yds >= 100:
            fpts += 3
        if self.pass_yds >= 300:
            fpts += 3
        self.fpts = round(fpts, 2)
        self.value = self.fpts / self.salary
        # print(self.name, str(self.fpts))
